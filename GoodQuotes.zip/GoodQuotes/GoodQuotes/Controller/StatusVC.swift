//
//  StatusVC.swift
//  GoodQuotes
//
//  Created by Rahul on 24/09/22.
//

import UIKit

class StatusVC: BaseVC {

    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblCat: UILabel!
    @IBOutlet weak var imgBack: UIImageView!
    
    @IBOutlet weak var imgBGHide: UIImageView!
    
    @IBOutlet weak var btnLike: UIButton!
    @IBOutlet weak var viewSS: viewEX!
    
    
    var arrStatus = [Any]()
    var selectIndex = Int()
    var strTitle = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.lblCat.text = strTitle
        
        setStatus()
        self.imgBack.image = imgBG
        self.imgBGHide.image = imgBG
    }
    
    
    
    @IBAction func btnLikeAction(_ sender: UIBarButtonItem) {
        
        let dictStatus = ["content": self.lblStatus.text ?? ""]
        var arrFav = DataManager.arrFav
        if arrFav.count > 0{
            if arrFav.contains(dictStatus){
                let findIndex = arrFav.firstIndex(where: {($0 as? [String: String])?["content"] == self.lblStatus.text ?? ""})
                if findIndex != nil{
                    arrFav.remove(at: findIndex!)
                    btnLike.isSelected = false
                }
            }else{
                arrFav.insert(dictStatus, at: 0)
                btnLike.isSelected = true
            }
            
        }else{
            arrFav.insert(dictStatus, at: 0)
            btnLike.isSelected = true
        }
        
        DataManager.arrFav = arrFav
    }
    
    @IBAction func btnShareAction(_ sender: UIButton) {
        
        self.imgBGHide.isHidden = false
        self.viewSS.borderColor = .clear
        let img = viewSS.takeScreenshot()
        self.imgBGHide.isHidden = true
        self.viewSS.borderColor = .darkGray
        DispatchQueue.main.async {
            self.share(shareImage: img)
        }
    }
    
    @IBAction func btnBackAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnBGAction(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "BackgroundVC") as! BackgroundVC
        vc.bgSet = {
            self.imgBack.image = imgBG
            self.imgBGHide.image = imgBG
        }
        self.present(vc, animated: true, completion: nil)
    }
    @available(iOS 14.0, *)

    @IBAction func btnColorAction(_ sender: UIButton) {
        let picker = UIColorPickerViewController()
        picker.selectedColor = .red
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }
    
    
    @IBAction func btnCopyAction(_ sender: UIButton) {
        if let dictSelect = self.arrStatus[selectIndex] as? [String: Any]{
            self.lblStatus.text = "\(dictSelect["content"] as? String ?? "")"
            UIPasteboard.general.string = self.lblStatus.text
        }
        let snackbar: TTGSnackbar = TTGSnackbar.init(message: "Copy Successfully !!!", duration: .middle)
        snackbar.backgroundColor = Constant.themeColor
        snackbar.animationType = .slideFromBottomToTop
        snackbar.show()
    }
    
    @IBAction func btnLeftAction(_ sender: UIButton) {
        if self.selectIndex != 0{
            selectIndex -= 1
            setStatus()
        }
    }
    
    func setStatus(){
        if let dictSelect = self.arrStatus[selectIndex] as? [String: Any]{
            self.lblStatus.text = "\(dictSelect["content"] as? String ?? "")"
        }
        
        let dict = ["content": self.lblStatus.text ?? ""]
        if DataManager.arrFav.count > 0{
            if DataManager.arrFav.count > 0{
                if DataManager.arrFav.contains(dict){
                    btnLike.isSelected = true
                }else{
                    btnLike.isSelected = false
                }
            }else{
                self.btnLike.isSelected = false
            }
        }
    }
    
    @IBAction func btnRightAction(_ sender: UIButton) {
        if self.selectIndex != arrStatus.count - 1 {
            selectIndex += 1
            setStatus()
        }
    }
    
    func share(shareImage:UIImage?){

        var objectsToShare = [AnyObject]()
        if let shareImageObj = shareImage{
            objectsToShare.append(shareImageObj)
        }
        if shareImage != nil{
            let activityViewController = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view
            present(activityViewController, animated: true, completion: nil)
        }else{
            print("There is nothing to share")
        }
    }
}
@available(iOS 14.0, *)

extension StatusVC : UIColorPickerViewControllerDelegate {
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        dismiss(animated: true, completion: nil)
    }
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        let color = viewController.selectedColor
        self.lblStatus.textColor = color
    }
}
