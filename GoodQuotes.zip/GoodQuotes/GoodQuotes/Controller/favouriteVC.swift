//
//  favouriteVC.swift
//  GoodQuotes
//
//  Created by Rahul on 24/09/22.
//

import UIKit

class favouriteVC: BaseVC {

    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var navigatioBar: UINavigationBar!
    
    var arrFav = [[String: Any]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigatioBar.setGradientBackground(colors: [Constant.themeColor, Constant.blackColor], startPoint: .topLeft, endPoint: .bottomRight)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.arrFav = DataManager.arrFav
        DispatchQueue.main.async {
            self.tblView.reloadData()
        }
    }
    
    
    @IBAction func barBtnBackAction(_ sender: UIBarButtonItem) {
        self.popVC(animation: true)
    }

}

extension favouriteVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if arrFav.count == 0{
            self.tblView.setEmptyMessage("No favorite any quote :)")
        }else{
            self.tblView.restore()
        }
        return arrFav.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: HomeList_Cell = tblView.dequeueReusableCell(withIdentifier: "HomeList_Cell", for: indexPath) as! HomeList_Cell
        if arrFav.count > 0{
            if let dictSelect = self.arrFav[indexPath.row] as? [String: Any]{
                cell.lblCategory.text = "\(dictSelect["content"] as? String ?? "")"
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "StatusVC") as! StatusVC
        vc.strTitle = "favourite Quotes"
        vc.selectIndex = indexPath.row
        vc.arrStatus = arrFav
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
