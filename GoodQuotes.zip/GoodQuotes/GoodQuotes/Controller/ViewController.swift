//
//  ViewController.swift
//  GoodQuotes
//
//  Created by Rahul on 23/09/22.
//

import UIKit

class ViewController: BaseVC {

    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var nvigationBar: UINavigationBar!
    var arrCategory = [Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.nvigationBar.setGradientBackground(colors: [Constant.themeColor, Constant.blackColor], startPoint: .topLeft, endPoint: .bottomRight)
        self.loadCategory()
    }
    
    @IBAction func btnLikeAction(_ sender: UIBarButtonItem) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "favouriteVC") as! favouriteVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnMenuAction(_ sender: UIBarButtonItem) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SettingsVC") as! SettingsVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func loadCategory(){
        if let path = Bundle.main.path(forResource: "GoodCategory", ofType: "json") {
            do {
                  let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                  let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                  if let jsonResult = jsonResult as? [Any] {
                      arrCategory = jsonResult
                      
                      DispatchQueue.main.async {
                          self.tblView.reloadData()
                      }
                  }
              } catch {
                  print("error")
              }
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCategory.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: HomeList_Cell = tblView.dequeueReusableCell(withIdentifier: "HomeList_Cell", for: indexPath) as! HomeList_Cell
        if arrCategory.count > 0{
            if let dictSelect = arrCategory[indexPath.row] as? [String: Any]{
                cell.lblCategory.text = "\(dictSelect["category_name"] as? String ?? "") Quotes"
                cell.imgCat.image = UIImage(named: "\(indexPath.row + 1)")
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let dictSelect = arrCategory[indexPath.row] as? [String: Any]{
            let vc = storyboard?.instantiateViewController(withIdentifier: "SubCategoryVC") as! SubCategoryVC
            vc.strtitle = "\(dictSelect["category_name"] as? String ?? "") Quotes"
            vc.selectCategotyID = dictSelect["id"] as? Int ?? 1
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

