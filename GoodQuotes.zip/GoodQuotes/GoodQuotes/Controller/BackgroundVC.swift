//
//  BackgroundVC.swift
//  GoodQuotes
//
//  Created by Rahul on 24/09/22.
//

import UIKit

class BackgroundVC: BaseVC {
    
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var tblView: UITableView!
    var bgSet:(() ->())?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationBar.setGradientBackground(colors: [Constant.themeColor, Constant.blackColor], startPoint: .topLeft, endPoint: .bottomRight)
    }

    @IBAction func barbtnBackAction(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true)
    }
}

extension BackgroundVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: HomeList_Cell = tblView.dequeueReusableCell(withIdentifier: "HomeList_Cell", for: indexPath) as! HomeList_Cell
        cell.ImgBG.image = UIImage(named: "grad\(indexPath.row + 1)")
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        imgBG = UIImage(named: "grad\(indexPath.row + 1)")!
        self.bgSet?()
        self.dismiss(animated: true)
    }
}
