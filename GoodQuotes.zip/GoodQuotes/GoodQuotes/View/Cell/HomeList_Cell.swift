//
//  HomeList_Cell.swift
//  GoodQuotes
//
//  Created by Rahul on 23/09/22.
//

import UIKit

class HomeList_Cell: UITableViewCell {

    @IBOutlet weak var ImgBG: UIImageView!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var imgCat: imgEx!
    @IBOutlet weak var viewBack: viewEX!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
