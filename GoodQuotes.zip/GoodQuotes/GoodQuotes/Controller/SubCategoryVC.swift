//
//  SubCategoryVC.swift
//  GoodQuotes
//
//  Created by Rahul on 23/09/22.
//

import UIKit

class SubCategoryVC: BaseVC {

    @IBOutlet weak var navigationBar: UINavigationBar!
    
    @IBOutlet weak var tblSubCategoty: UITableView!
    
    var strtitle = String()
    var selectCategotyID = Int()
    var arrSubStatus = [Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationBar.setGradientBackground(colors: [Constant.themeColor, Constant.blackColor], startPoint: .topLeft, endPoint: .bottomRight)
        self.navigationBar.topItem?.title = strtitle
        self.getSubCategoty()
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.popVC(animation: true)
    }
    

    func getSubCategoty() {
        if let path = Bundle.main.path(forResource: "CategorySubStatus", ofType: "json") {
            do {
                  let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                  let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                  if let jsonResult = jsonResult as? [Any] {
                      self.arrSubStatus = jsonResult
                      self.arrSubStatus = self.arrSubStatus.filter({($0 as? [String: Any])!["category_id"] as? Int ?? 0 == selectCategotyID})
                      print("statusss::", self.arrSubStatus)
                      
                      DispatchQueue.main.async {
                          self.tblSubCategoty.reloadData()
                      }
                  }
              } catch {
                  print("error")
              }
        }
    }
}

extension SubCategoryVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSubStatus.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: HomeList_Cell = tblSubCategoty.dequeueReusableCell(withIdentifier: "HomeList_Cell", for: indexPath) as! HomeList_Cell
        if arrSubStatus.count > 0{
            if let dictSelect = self.arrSubStatus[indexPath.row] as? [String: Any]{
                cell.lblCategory.text = "\(dictSelect["content"] as? String ?? "")"
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let dictSelect = arrSubStatus[indexPath.row] as? [String: Any]{
            let vc = storyboard?.instantiateViewController(withIdentifier: "StatusVC") as! StatusVC
            vc.strTitle = strtitle
            vc.selectIndex = indexPath.row
            vc.arrStatus = arrSubStatus
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
