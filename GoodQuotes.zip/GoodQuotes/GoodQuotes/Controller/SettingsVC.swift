//
//  SettingsVC.swift
//  GoodQuotes
//
//  Created by Rahul on 26/09/22.
//

import UIKit

class SettingsVC: BaseVC {

    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var navigatioBAr: UINavigationBar!
    
    var arrSettings = ["Rate Us", "Privacy Plocity", "Invite Friends"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigatioBAr.setGradientBackground(colors: [Constant.themeColor, Constant.blackColor], startPoint: .topLeft, endPoint: .bottomRight)
        self.tblView.reloadData()
    }
    

    @IBAction func barbtnBackAction(_ sender: Any) {
        self.popVC(animation: true)
    }
}


extension SettingsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSettings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: HomeList_Cell = tblView.dequeueReusableCell(withIdentifier: "HomeList_Cell", for: indexPath) as! HomeList_Cell
        cell.lblCategory.text = "\(arrSettings[indexPath.row])"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            guard let url = URL(string: Constant.ReviewURl) else { return }
            UIApplication.shared.open(url)
        }else if indexPath.row == 1{
            guard let url = URL(string: Constant.url_Terms) else { return }
            UIApplication.shared.open(url)
        }else{
            let objectsToShare = "Download \(Constant.AppName) and Share \(Constant.AppName) to your Friends" as Any
            if let name = NSURL(string: "\(Constant.appUrl)") {
                let activityVC = UIActivityViewController(activityItems: ["\(objectsToShare) \n\n \(name)"], applicationActivities: nil)
                activityVC.setValue(Constant.AppName, forKey: "subject")
                if UIDevice.current.userInterfaceIdiom == .pad {
                    activityVC.popoverPresentationController?.sourceView = self.view
//                    activityVC.popoverPresentationController?.sourceRect = sender.frame
                }
                self.present(activityVC, animated: true, completion: nil)
            }
        }
    }
}
