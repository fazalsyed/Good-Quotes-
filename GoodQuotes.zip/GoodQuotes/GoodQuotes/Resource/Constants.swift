//
//  Constants.swift
//  GoodQuotes
//
//  Created by Rahul on 23/09/22.
//

import UIKit
import Foundation

var imgBG = UIImage()
var arrImg = [UIImage]()

class Constant: NSObject {
    static let themeColor : UIColor = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)
    static let blackColor : UIColor = #colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1)
    
    static let AppName = "Good Motivation Quotes"
    static let url_Terms = "https://www.privacypolicygenerator.info/live.php?token=8ilteYueyTxAi7nmoY9XZISBb33MNEsm"

    static let appId = "id6443579692"
    static let appUrl = "https://apps.apple.com/app/\(appId)"
    static let ReviewURl = "itms-apps://itunes.apple.com/app/id/\(appId)?action=write-review"
}

let defaults = UserDefaults.standard

class DataManager {
    static var arrFav: [[String: String]] {
        set {
            defaults.set(newValue, forKey: #function)
        }
        get {
            return defaults.value(forKey: #function) as? [[String : String]] ?? [[String : String]]()
        }
    }
}



extension UITableView {

    func setEmptyMessage(_ message: String) {
        let messageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.bounds.size.width, height: self.bounds.size.height))
        messageLabel.text = message
        messageLabel.textColor = .black
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont(name: "TrebuchetMS", size: 17)
        messageLabel.sizeToFit()

        self.backgroundView = messageLabel
        self.separatorStyle = .none
    }

    func restore() {
        self.backgroundView = nil
        self.separatorStyle = .singleLine
    }
}
